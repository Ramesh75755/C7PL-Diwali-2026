# C7PL Diwali Utsav 2026

A mobile-friendly static celebration website made with HTML, CSS and JavaScript.

## Files
- `index.html` — website structure
- `style.css` — premium black, purple and gold design
- `app.js` — navigation, fireworks, countdown, team roster and sharing

## Run in Termux
```bash
pkg update -y
pkg install python git -y
cd C7PL-Diwali-Utsav-2026
python -m http.server 8080
```
Open `http://127.0.0.1:8080` in Chrome.

## Publish with GitHub Pages
1. Create a new public GitHub repository, for example `c7pl-diwali-utsav-2026`.
2. Upload all files in this folder. Keep `index.html` in the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. Your URL will look like:
   `https://YOUR-USERNAME.github.io/c7pl-diwali-utsav-2026/`

## Important notes
- This is a static front-end website. The player names added in the team section are saved only in the current browser using localStorage. They are not shared with other visitors.
- For one shared player list visible to everyone, connect a Firebase Firestore database and add suitable security rules before publishing.
- The share button uses the browser's native share sheet when supported.
- The countdown target is set to 8 November 2026, 6:00 PM India time. Change `targetDate` in `app.js` if you want another time.
- The site uses Google Fonts when internet access is available; system fonts are used as fallback.
