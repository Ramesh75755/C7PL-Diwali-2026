const $ = (id) => document.getElementById(id);

// Simple page navigation
document.querySelectorAll("[data-go]").forEach(button => {
  button.addEventListener("click", () => showScreen(button.dataset.go));
});
function showScreen(id) {
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  $(id).classList.add("active");
  window.scrollTo({top:0, behavior:"smooth"});
  if (id === "home" || id === "celebrate") burstAt(innerWidth/2, innerHeight*.35, 65);
}

// Diya interaction
$("magicDiya").addEventListener("click", () => {
  $("magicDiya").classList.toggle("lit");
  burstAt(innerWidth/2, innerHeight*.45, 90);
  $("magicDiya").querySelector("span").textContent =
    $("magicDiya").classList.contains("lit") ? "Your light is shining!" : "Tap to light";
});

// Team roster: local browser demo. Replace with Firebase for a shared live database.
const teams = ["GL","KBS","LSK","WK"];
let selectedTeam = "GL";
let roster = {};
try { roster = JSON.parse(localStorage.getItem("c7pl-roster") || "{}"); } catch { roster = {}; }
teams.forEach(t => { if (!Array.isArray(roster[t])) roster[t] = []; });

document.querySelectorAll(".team-card").forEach(card => {
  card.addEventListener("click", () => {
    selectedTeam = card.dataset.team;
    document.querySelectorAll(".team-card").forEach(c => c.classList.toggle("selected", c === card));
    renderPlayers();
  });
});
function renderPlayers() {
  $("rosterHeading").textContent = selectedTeam + " Players";
  $("playerCount").textContent = `${roster[selectedTeam].length} players`;
  const list = $("playerList");
  list.replaceChildren();
  if (!roster[selectedTeam].length) {
    const p = document.createElement("p");
    p.className = "empty-state";
    p.textContent = "Player names will appear here once added.";
    list.append(p);
    return;
  }
  roster[selectedTeam].forEach((name, index) => {
    const row = document.createElement("div");
    row.className = "player-item";
    const number = document.createElement("span");
    number.className = "player-number";
    number.textContent = String(index + 1).padStart(2,"0");
    const text = document.createElement("span");
    text.textContent = name;
    row.append(number,text);
    list.append(row);
  });
}
$("playerForm").addEventListener("submit", event => {
  event.preventDefault();
  const input = $("playerName");
  const name = input.value.trim();
  if (!name) return;
  if (roster[selectedTeam].some(n => n.toLowerCase() === name.toLowerCase())) {
    $("shareStatus").textContent = "That player is already in this team.";
    return;
  }
  roster[selectedTeam].push(name);
  localStorage.setItem("c7pl-roster", JSON.stringify(roster));
  input.value = "";
  renderPlayers();
});
renderPlayers();

// Diwali countdown: 8 November 2026, 6:00 PM India time (editable date)
const targetDate = new Date("2026-11-08T18:00:00+05:30").getTime();
function updateCountdown() {
  let diff = targetDate - Date.now();
  if (diff <= 0) {
    ["days","hours","minutes","seconds"].forEach(id => $(id).textContent = "00");
    return;
  }
  const values = [
    Math.floor(diff / 86400000),
    Math.floor((diff % 86400000) / 3600000),
    Math.floor((diff % 3600000) / 60000),
    Math.floor((diff % 60000) / 1000)
  ];
  ["days","hours","minutes","seconds"].forEach((id,i) =>
    $(id).textContent = String(values[i]).padStart(i===0?3:2,"0"));
}
updateCountdown();
setInterval(updateCountdown,1000);

// Sharing
const shareText = "✨ Happy Diwali 2026! 🎆 Sending love and light to the C7PL family. 🪔";
$("shareBtn").addEventListener("click", async () => {
  const data = {title:"C7PL Diwali Utsav 2026", text:shareText, url:location.href};
  try {
    if (navigator.share) await navigator.share(data);
    else { await navigator.clipboard.writeText(`${shareText}\n${location.href}`); $("shareStatus").textContent="Wish and link copied!"; }
  } catch (e) { if (e.name !== "AbortError") $("shareStatus").textContent="Sharing is unavailable in this browser."; }
});
$("copyBtn").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(location.href); $("shareStatus").textContent="Website link copied. Share it with everyone!"; }
  catch { $("shareStatus").textContent="Copy unavailable. Copy the address from your browser."; }
});
const dialog = $("wishDialog");
$("cardBtn").addEventListener("click", () => dialog.showModal());
$("wishName").addEventListener("input", updateWishPreview);
function updateWishPreview() {
  const name = $("wishName").value.trim();
  $("wishPreview").textContent = name
    ? `Happy Diwali 2026! With warm wishes, ${name} ✨`
    : "Wishing you a very Happy Diwali!";
}
$("shareWish").addEventListener("click", async () => {
  const name = $("wishName").value.trim();
  const text = name ? `Happy Diwali 2026! With warm wishes, ${name} ✨` : shareText;
  try {
    if (navigator.share) await navigator.share({title:"A Diwali wish from C7PL",text,url:location.href});
    else { await navigator.clipboard.writeText(`${text}\n${location.href}`); $("shareStatus").textContent="Your personal wish was copied!"; }
    dialog.close();
  } catch (e) { if (e.name !== "AbortError") $("shareStatus").textContent="Could not share from this browser."; }
});

// Sound button: a gentle synthesized chime, only after user interaction.
let audioContext = null, soundOn = false;
$("soundToggle").addEventListener("click", () => {
  soundOn = !soundOn;
  $("soundToggle").setAttribute("aria-pressed", String(soundOn));
  $("soundToggle").querySelector("span").textContent = soundOn ? "Sound on" : "Sound off";
  if (soundOn) playChime();
});
function playChime() {
  if (!soundOn) return;
  try {
    audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioContext.createOscillator(), gain = audioContext.createGain();
    osc.type = "sine"; osc.frequency.value = 660;
    gain.gain.setValueAtTime(.0001,audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(.07,audioContext.currentTime+.04);
    gain.gain.exponentialRampToValueAtTime(.0001,audioContext.currentTime+.8);
    osc.connect(gain); gain.connect(audioContext.destination);
    osc.start(); osc.stop(audioContext.currentTime+.82);
  } catch {}
}

// Canvas fireworks
const canvas = $("fireworks"), ctx = canvas.getContext("2d");
let particles = [];
function resizeCanvas() {
  const dpr = Math.min(devicePixelRatio || 1, 2);
  canvas.width = innerWidth*dpr; canvas.height = innerHeight*dpr;
  ctx.setTransform(dpr,0,0,dpr,0,0);
}
addEventListener("resize", resizeCanvas); resizeCanvas();
const palette = ["#f8d88d","#ff9b70","#e6a6ff","#9de7ff","#fff4d5","#f5a6c9"];
function burstAt(x,y,count=55) {
  for(let i=0;i<count;i++) {
    const a=Math.random()*Math.PI*2, speed=Math.random()*3.8+.5;
    particles.push({x,y,vx:Math.cos(a)*speed,vy:Math.sin(a)*speed,
      life:55+Math.random()*40,max:95,size:Math.random()*2+1,
      color:palette[Math.floor(Math.random()*palette.length)]});
  }
}
function frame() {
  ctx.clearRect(0,0,innerWidth,innerHeight);
  if (Math.random()<.025) burstAt(Math.random()*innerWidth,Math.random()*innerHeight*.48,35);
  particles = particles.filter(p=>p.life>0);
  for(const p of particles) {
    p.x+=p.vx; p.y+=p.vy; p.vy+=.025; p.vx*=.992; p.life--;
    ctx.globalAlpha=Math.max(0,p.life/p.max);
    ctx.fillStyle=p.color; ctx.shadowBlur=10; ctx.shadowColor=p.color;
    ctx.beginPath(); ctx.arc(p.x,p.y,p.size,0,Math.PI*2); ctx.fill();
  }
  ctx.globalAlpha=1; ctx.shadowBlur=0;
  requestAnimationFrame(frame);
}
frame();
setTimeout(()=>burstAt(innerWidth*.5,innerHeight*.3,100),500);
